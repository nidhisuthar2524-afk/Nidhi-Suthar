// Image paths (replace these with your actual image file paths or URLs)
const images = [
    "image1.jpg",
    "image2.jpg",
    "image3.jpg",
    "image4.jpg",
    "image5.jpg"
  ];
  
  let currentIndex = 0;
  const sliderImage = document.getElementById("slider-image");
  
  // Display the first image on load
  function showImage(index) {
    sliderImage.style.opacity = 0;
    setTimeout(() => {
      sliderImage.src = images[index];
      sliderImage.style.opacity = 1;
    }, 200);
  }
  
  function prevSlide() {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    showImage(currentIndex);
  }
  
  function nextSlide() {
    currentIndex = (currentIndex + 1) % images.length;
    showImage(currentIndex);
  }

  // Automatic slideshow
setInterval(() => {
  nextSlide();
}, 1000); 
  
   // Initialize
  document.addEventListener("DOMContentLoaded", () => {
    showImage(currentIndex);
  });
  