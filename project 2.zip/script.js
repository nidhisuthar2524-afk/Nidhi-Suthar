const cardsArray = [
    "image1.png", "image2.png", "image3.png", "image4.png",
    "image5.png", "image6.png", "image7.png", "image8.png"
  ];
  
  let cards = [...cardsArray, ...cardsArray]; // duplicate cards for pairs
  let gameBoard = document.getElementById("gameBoard");
  let movesCounter = document.getElementById("moves");
  let timerDisplay = document.getElementById("timer");
  let congrats = document.getElementById("congrats");
  
  let flippedCards = [];
  let matchedPairs = 0;
  let moves = 0;
  let timer;
  let seconds = 0;
  let isStarted = false;
  
  function shuffle(array) {
    return array.sort(() => Math.random() - 0.5);
  }
  
  function startGame() {
    gameBoard.innerHTML = "";
    cards = shuffle([...cardsArray, ...cardsArray]);
    flippedCards = [];
    matchedPairs = 0;
    moves = 0;
    seconds = 0;
    isStarted = false;
    movesCounter.textContent = "0";
    timerDisplay.textContent = "0";
    congrats.classList.add("hidden");
  
    clearInterval(timer);
  
    cards.forEach((src, index) => {
      const card = document.createElement("div");
      card.classList.add("card");
      card.dataset.index = index;
      card.dataset.image = src;
  
      const img = document.createElement("img");
      img.src = src;
      card.appendChild(img);
  
      card.addEventListener("click", () => flipCard(card));
      gameBoard.appendChild(card);
    });
  }
  
  function flipCard(card) {
    if (!isStarted) {
      isStarted = true;
      timer = setInterval(() => {
        seconds++;
        timerDisplay.textContent = seconds;
      }, 1000);
    }
  
    if (flippedCards.length < 2 && !card.classList.contains("flipped")) {
      card.classList.add("flipped");
      flippedCards.push(card);
  
      if (flippedCards.length === 2) {
        moves++;
        movesCounter.textContent = moves;
        checkMatch();
      }
    }
  }
  
  function checkMatch() {
    const [card1, card2] = flippedCards;
    const isMatch = card1.dataset.image === card2.dataset.image;
  
    if (isMatch) {
      matchedPairs++;
      flippedCards = [];
  
      if (matchedPairs === cardsArray.length) {
        clearInterval(timer);
        congrats.classList.remove("hidden");
      }
    } else {
      setTimeout(() => {
        card1.classList.remove("flipped");
        card2.classList.remove("flipped");
        flippedCards = [];
      }, 800);
    }
  }
  
  // Start first time
  startGame();
  